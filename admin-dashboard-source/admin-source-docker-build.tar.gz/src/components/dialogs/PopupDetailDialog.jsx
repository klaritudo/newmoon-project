import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Divider
} from '@mui/material';

const PopupDetailDialog = ({ open, onClose, popup, onEdit, onDelete }) => {
  if (!popup) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        � �8 �
      </DialogTitle>
      <DialogContent dividers>
        <Typography variant="h6" gutterBottom>
          {popup.title}
        </Typography>
        
        <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', color: 'text.secondary' }}>
          <Typography variant="body2">
            �1�: {popup.writer} | 
            �]|: {popup.createdAt} | 
            |: {popup.updatedAt}
          </Typography>
          <Typography variant="body2">
            ��: {popup.popupType} | 
            ��: {popup.status}
          </Typography>
        </Box>
        
        <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', color: 'text.secondary' }}>
          <Typography variant="body2">
            X: {popup.position} | 
             �: {popup.target}
          </Typography>
          <Typography variant="body2">
            l0: {popup.width}x{popup.height}px | 
            ܑ|: {popup.startDate} | 
            ��|: {popup.endDate}
          </Typography>
        </Box>
        
        <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', color: 'text.secondary' }}>
          <Typography variant="body2">
            x�: {popup.viewCount?.toLocaleString() || 0}� | 
            t�: {popup.clickCount?.toLocaleString() || 0}�
          </Typography>
          <Typography variant="body2">
            t�� �0: {popup.closeOnClick ? '' : 'D�$'} | 
            \�� \�: {popup.showOnce ? '' : 'D�$'}
          </Typography>
        </Box>
        
        <Divider sx={{ mb: 2 }} />
        
        <Typography variant="body1" component="div" sx={{ whiteSpace: 'pre-wrap' }}>
          {popup.content}
        </Typography>
        
        {popup.imageUrl && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="body2" sx={{ mb: 1, color: 'text.secondary' }}>
              t�� URL: {popup.imageUrl}
            </Typography>
          </Box>
        )}
        
        {popup.linkUrl && (
          <Box sx={{ mt: 1 }}>
            <Typography variant="body2" sx={{ color: 'text.secondary' }}>
              �l URL: {popup.linkUrl}
            </Typography>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>�0</Button>
        {onEdit && (
          <Button onClick={() => {
            onClose();
            onEdit(popup);
          }}></Button>
        )}
        {onDelete && (
          <Button color="error" onClick={() => {
            onClose();
            onDelete(popup);
          }}>�</Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default PopupDetailDialog;