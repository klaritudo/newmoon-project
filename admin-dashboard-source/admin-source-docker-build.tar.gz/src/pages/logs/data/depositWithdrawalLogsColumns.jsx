// 입출금 로그 컬럼 정의
export const depositWithdrawalLogsColumns = [
  {
    id: 'checkbox',
    type: 'checkbox',
    width: 50,
    sortable: false,
    pinnable: true
  },
  {
    id: 'number',
    type: 'number',
    header: 'No.',
    width: 70,
    align: 'center',
    pinnable: true
  },
  {
    id: 'processDate',
    header: '처리일시',
    type: 'default',
    width: 180,
    sortable: true,
    pinnable: true
  },
  {
    id: 'type',
    header: '유형',
    type: 'chip',
    width: 80,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      return {
        color: value === '입금' ? 'success' : 'error',
        variant: 'filled',
        size: 'small'
      };
    }
  },
  {
    id: 'status',
    header: '상태',
    type: 'chip',
    width: 100,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      const statusColors = {
        '대기': 'default',
        '진행중': 'warning',
        '승인': 'success',
        '거절': 'error'
      };
      
      return {
        color: statusColors[value] || 'default',
        variant: 'outlined',
        size: 'small'
      };
    }
  },
  {
    id: 'memberInfo',
    header: '회원정보',
    type: 'default',
    width: 150,
    sortable: true,
    pinnable: true
  },
  {
    id: 'amount',
    header: '금액',
    type: 'currency',
    width: 120,
    align: 'right',
    sortable: true
  },
  {
    id: 'bankInfo',
    header: '은행정보',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'depositorName',
    header: '입금자명',
    type: 'default',
    width: 100,
    sortable: true
  },
  {
    id: 'processedBy',
    header: '처리자',
    type: 'default',
    width: 120,
    sortable: true
  },
  {
    id: 'balanceBefore',
    header: '처리전잔액',
    type: 'currency',
    width: 120,
    align: 'right',
    sortable: false
  },
  {
    id: 'balanceAfter',
    header: '처리후잔액',
    type: 'currency',
    width: 120,
    align: 'right',
    sortable: false
  },
  {
    id: 'memo',
    header: '메모',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'rejectReason',
    header: '거절사유',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'ip',
    header: 'IP',
    type: 'default',
    width: 140,
    sortable: true
  }
];