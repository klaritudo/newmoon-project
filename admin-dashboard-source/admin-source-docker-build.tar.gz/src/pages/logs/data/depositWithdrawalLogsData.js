// 입출금 로그 데이터 생성
import { depositWithdrawalLogsColumns } from './depositWithdrawalLogsColumns';

// 랜덤 데이터 생성을 위한 헬퍼 함수
const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];

const types = ['입금', '출금'];
const statuses = ['대기', '진행중', '승인', '거절'];
const adminIds = ['admin001', 'admin002', 'manager01', 'manager02', 'supervisor1'];
const memberInfo = [
  { id: 'user1234', nickname: 'GoldPlayer' },
  { id: 'player001', nickname: 'ProGamer' },
  { id: 'member999', nickname: 'LuckyOne' },
  { id: 'test_user', nickname: 'TestPlayer' },
  { id: 'demo_account', nickname: 'DemoUser' },
  { id: 'vip_player1', nickname: 'VIPGold' },
  { id: 'gold_member', nickname: 'GoldMember' },
  { id: 'silver123', nickname: 'SilverUser' }
];

const banks = ['국민은행', '신한은행', '우리은행', '하나은행', '농협', '기업은행', '카카오뱅크', '토스뱅크'];

const memos = {
  '입금': [
    '정상 입금 처리',
    '이벤트 보너스 포함',
    '첫 입금 보너스 적용',
    'VIP 추가 보너스',
    '주말 이벤트 적용'
  ],
  '출금': [
    '정상 출금 처리',
    '신속 출금 완료',
    '대량 출금 요청',
    '부분 출금 처리',
    '긴급 출금 승인'
  ]
};

const rejectReasons = [
  '입금자명 불일치',
  '계좌정보 오류',
  '한도 초과',
  '중복 신청',
  '본인 확인 실패',
  '서류 미비',
  '보안 정책 위반'
];

// IP 생성 함수
const generateIP = () => {
  return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
};

// 날짜 생성 함수 (최근 30일)
const generateDate = (index) => {
  const now = new Date();
  const hoursAgo = index * 2; // 2시간 간격
  const date = new Date(now.getTime() - (hoursAgo * 60 * 60 * 1000));
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// 입출금 로그 데이터 생성
export const generateDepositWithdrawalLogsData = (count = 100) => {
  const data = [];
  let currentBalance = 10000000; // 초기 잔액 1000만원
  
  for (let i = 0; i < count; i++) {
    const type = getRandomElement(types);
    const status = getRandomElement(statuses);
    const member = getRandomElement(memberInfo);
    const amount = Math.floor(Math.random() * 5000000) + 10000; // 1만원 ~ 500만원
    const bank = getRandomElement(banks);
    const accountNumber = `${Math.floor(Math.random() * 1000)}-${Math.floor(Math.random() * 10000)}-${Math.floor(Math.random() * 100000)}`;
    
    // 잔액 계산 (승인된 경우만)
    let balanceBefore = currentBalance;
    let balanceAfter = currentBalance;
    
    if (status === '승인') {
      if (type === '입금') {
        balanceAfter = currentBalance + amount;
        currentBalance = balanceAfter;
      } else {
        balanceAfter = currentBalance - amount;
        currentBalance = balanceAfter;
      }
    }
    
    const logEntry = {
      id: count - i,
      processDate: generateDate(i),
      type: type,
      status: status,
      memberInfo: `${member.id} (${member.nickname})`,
      amount: amount,
      bankInfo: `${bank} ${accountNumber}`,
      depositorName: type === '입금' ? member.nickname : '-',
      processedBy: status === '대기' ? '-' : getRandomElement(adminIds),
      balanceBefore: status === '승인' ? balanceBefore : null,
      balanceAfter: status === '승인' ? balanceAfter : null,
      memo: status === '대기' ? '' : getRandomElement(memos[type]),
      rejectReason: status === '거절' ? getRandomElement(rejectReasons) : '',
      ip: generateIP()
    };
    
    data.push(logEntry);
  }
  
  return data;
};

// 컬럼 export
export { depositWithdrawalLogsColumns };