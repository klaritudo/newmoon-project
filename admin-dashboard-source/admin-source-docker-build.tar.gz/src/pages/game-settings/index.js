export { default as SlotSettingPage } from './SlotSettingPage';
export { default as CasinoSettingPage } from './CasinoSettingPage';