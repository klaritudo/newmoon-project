// Production configuration
window.API_CONFIG = {
  API_URL: "/api",  // Use relative path for production
  PUBLIC_URL: "/public"  // Public assets path
};
